import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
import requests


def send_http_request(target, method, headers=None, payload=None):
    """
    HTTP-requests: GET, POST, HEAD, PUT, PATCH, TRACE.
    """
    headers_dict = {}
    if headers:
        for header in headers:
            header_name = header.split(':')[0].strip()
            header_value = ':'.join(header.split(':')[1:]).strip()
            headers_dict[header_name] = header_value

    try:
        if method.upper() == "GET":
            response = requests.get(target, headers=headers_dict)
        elif method.upper() == "POST":
            response = requests.post(target, headers=headers_dict, data=payload)
        elif method.upper() == "HEAD":
            response = requests.head(target, headers=headers_dict)
        elif method.upper() == "PUT":
            response = requests.put(target, headers=headers_dict, data=payload)
        elif method.upper() == "PATCH":
            response = requests.patch(target, headers=headers_dict, data=payload)
        elif method.upper() == "TRACE":
            response = requests.request("TRACE", target, headers=headers_dict)
        else:
            return {"error": f"Unsupported HTTP method: {method}"}

        return {
            "status_code": response.status_code,
            "headers": dict(response.headers),
            "content": response.text if method.upper() not in ["HEAD", "TRACE"] else None
        }
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}


def do_ping_sweep(ip, num_of_hosts):
    """
    IP-scanner.
    """
    ip_parts = ip.split('.')
    if len(ip_parts) != 4:
        return {"error": "Invalid IP address format. Expected IPv4, for example: 192.168.0.1"}

    try:
        start_ip = int(ip_parts[3])  # make  IP. Last octet  
    except ValueError:
        return {"error": "Invalid IP address format"}

    network_ip = '.'.join(ip_parts[:3])  # Base octets
    results = []  # list of results 

    for i in range(1, num_of_hosts + 1):
        current_ip = f"{network_ip}.{start_ip + i}"
        response = os.popen(f'ping -c 1 {current_ip}').read()
        if 'ttl' in response.lower():  # if ping success?
            results.append({"ip": current_ip, "status": "up"})
        else:
            results.append({"ip": current_ip, "status": "down"})

    return results


class ServiceHandler(BaseHTTPRequestHandler):
    """
    HTTP API.
    """

    def _send_response(self, response_data, code=200):
        """response"""
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(response_data, indent=2).encode("utf-8"))

    # obrabotka HTTP-requests
    def do_GET(self):
        """GET"""
        path = self.path
        if "/scan" in path:
            # example: GET /scan body '{"target": "192.168.1.0", "count": "20"}'
            content_length = int(self.headers.get('Content-Length', 0))
            get_data = self.rfile.read(content_length).decode('utf-8')

            try:
                request_data = json.loads(get_data)
                target = request_data.get("target")
                count = int(request_data.get("count"))
                scan_results = do_ping_sweep(target, count)
                self._send_response({"scan_results": scan_results})
            except json.JSONDecodeError:
                self._send_response({"error": "Invalid JSON format"}, code=400)
            except ValueError:
                self._send_response({"error": "Invalid count value"}, code=400)
        else:
            self._send_response({"error": "Invalid endpoint"}, code=404)

    def do_POST(self):
        """POST sendhttp"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')

        try:
            request_data = json.loads(post_data)
            if 'task' in request_data and request_data['task'] == 'sendhttp':
                target = request_data.get('target')
                method = request_data.get('method')
                headers = request_data.get('headers', [])
                payload = request_data.get('payload', None)
                result = send_http_request(target, method, headers, payload)
                self._send_response(result)
            else:
                self._send_response({"error": "Invalid task or data format"}, code=400)
        except json.JSONDecodeError:
            self._send_response({"error": "Invalid JSON format"}, code=400)

    def do_HEAD(self):
        """HEAD"""
        self.handle_http_request("HEAD")

    def do_PUT(self):
        """PUT"""
        self.handle_http_request("PUT")

    def do_PATCH(self):
        """PATCH"""
        self.handle_http_request("PATCH")

    def do_TRACE(self):
        """TRACE"""
        self.handle_http_request("TRACE")

    def handle_http_request(self, method):
        """HTTP-requests HEAD, PUT, PATCH, TRACE"""
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')

        try:
            request_data = json.loads(post_data)
            target = request_data.get('target')
            headers = request_data.get('headers', [])
            payload = request_data.get('payload', None)
            result = send_http_request(target, method, headers, payload)
            self._send_response(result)
        except json.JSONDecodeError:
            self._send_response({"error": "Invalid JSON format"}, code=400)


def run(server_class=HTTPServer, handler_class=ServiceHandler, port=3000):
    """
    run server
    """
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Server started on port {port}")
    httpd.serve_forever()


if __name__ == "__main__":
    run()
